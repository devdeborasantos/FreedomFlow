package com.example.freedomflow

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
